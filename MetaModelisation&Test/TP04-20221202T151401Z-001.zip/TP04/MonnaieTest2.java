/** MonnaieTest2 : Vérifier que les méthodes de test de la superclasse sont bien
  * prises en compte !
  * @author	Xavier Crégut
  * @version	$Revision$
  */
public class MonnaieTest2 extends MonnaieTest {

	public void testSupplementaire() {
		// OK.
	}

}
