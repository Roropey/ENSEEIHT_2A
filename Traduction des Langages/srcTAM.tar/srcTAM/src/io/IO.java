package io;

public interface IO {

    public void print(String l);

    public int readInt();

    public boolean readBool();

    public char readChar();

    public String readString();
}