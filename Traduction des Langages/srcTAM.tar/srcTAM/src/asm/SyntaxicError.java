package asm;

public class SyntaxicError extends RuntimeException {
    SyntaxicError(String msg) {
        super(msg);
    }
}