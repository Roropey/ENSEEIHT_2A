package asm;

public class SemanticError extends Exception {
    SemanticError(String msg) {
        super(msg);
    }
}