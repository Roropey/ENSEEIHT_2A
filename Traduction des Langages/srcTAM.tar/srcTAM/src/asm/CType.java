package asm;

/**
 * Type of the constants in TAM. This must the same values as in the TAM machine
 * (LOADL_int, LOADL_string, LOADL_char).
 */
public class CType {
    public static final int Entier = 0;
    public static final int Chaine = 1;
    public static final int Char = 2;
}
