Pour compiler :

javac UsagerServer_i.java
javac UsagerClient.java

Puis pour lancer :

java UsagerServer_i 0
java UsagerServer_i 1
java UsagerServer_i 2
java UsagerClient
