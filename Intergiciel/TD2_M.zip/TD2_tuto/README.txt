Dans Serveur :

javac *java
java Arbitre

Dans Client :

javac *java
java Joueur
