Dans Serveur :

javac *java
java MOMImpl topic1 topic2 topic3

Dans Client :

javac *java
java Subscriber topic2
java Subscriber topic3
java Publisher topic2
java Publisher topic3
java Publisher topic1
