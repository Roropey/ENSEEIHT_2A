Problème des lecteurs/rédacteurs
================================

Objectif
--------
Écrire des implantations de LectRed.java.

Stratégies à implanter :

 - priorité aux rédacteurs ou aux lecteurs
 - équitable (absence de famine que ce soient des lecteurs ou des rédacteurs)


Compilation
-----------
    javac *.java Synchro/*.java

Exécution
---------
    java Main

Le programme trouve automatiquement toutes les implantations disponibles
dans le répertoire (par réflexivité), et en particulier les nouvelles
implantations rajoutées.

Il est par ailleurs également possible de lancer une implantation particulière par :

    java Main <l'implantation écrite> <nb lecteurs> <nb rédacteurs>

par exemple:

    java Main MonImplantation 6 4



